#!/bin/sh
cd "$(dirname "$0")"
clear

	echo "Confirm final stage of uninstallation of Counter-Strike 1.6 Bots & Bot Menu?"
	echo " "
	echo "This will permanantly delete related files, even if you have modified them yourself!"
	echo " "
	echo "Type y to continue, or anything else to cancel, then press Enter once on your keyboard to confirm your choice."
	echo " "
	echo -n "Choice: "
	read input
	echo " "

case $input in
        y)
			echo "*** Deleting files ***"
			echo " "
			rm "cstrike/cl_dlls/GameUI.dll"
			rm "czero/cl_dlls/GameUI.dll"
			echo "*** Disabling application of ReGameDLL_CS game configuration files ***"
			mv "cstrike/game.cfg" "cstrike/game.cfg_disabled"
			mv "cstrike/game_init.cfg" "cstrike/game_init.cfg_disabled"
			echo " "
			echo "*** Done ***"
			echo " "
			echo "You may now close this window."
			echo " "
			;;
		*)
			echo "Final stage of uninstallation cancelled - no files were deleted. You may now close this window."
			echo " "
			;;
	esac
	read dummy
