#!/bin/sh
cd "$(dirname "$0")"
clear
x-terminal-emulator -hold -e ./zFinalStageOfUninstallingBotsScript.sh
			;;
	esac
